public class Node{
Element e;
Node next;
public Node(Element a){
next=null;
e=a;
}
}