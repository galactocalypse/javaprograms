public class SElement extends Element{
public SElement(){super(null);}
public SElement(String s){
super(s);
}

}