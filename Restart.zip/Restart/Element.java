public class Element{
String name;
public Element(String s){name=s;}
public Element(){}
}