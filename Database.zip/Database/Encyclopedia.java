import java.io.*;
public class Encyclopedia{
Buffer b;
public Encyclopedia(Buffer bu){b=bu;}
public ArticleList search(String s){

ArticleList e=new ArticleList();
e.addAtEnd(b.users.searchAll(s));
return e;
}
Article searchResult(String s){
ArticleList a=search(s);
a.dispNames();
do{
String s1=b.r.input("Enter article to dislay(enter .x. to stop search) : ");
Article res=(Article)a.search(s1);
if(res!=null)return res;
if(s1.equalsIgnoreCase(".x."))return null;
}while(a==null);
return null;
}
public void searchWord(String keyword){
Article a=searchResult(keyword);
b.w.sopln(a.disp());
}
}