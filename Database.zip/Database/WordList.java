public class WordList extends ElementList{
public WordList(){
    super();    
    }
      
    }